package pages;

import commonMthods.ActionKeywords;

public class AddressbookPage {
	
	public static void frstName(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);
	}
	
	public static void lasttName(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);
	}
	
	public static void userName(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);
	}
	
	public static void password(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);
	}
	
	public static void cnfrmpsswd(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);
	}
	
	public static void emailid(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);
	}
	
	public static void companyName(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);
	}
	
	public static void streetName(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);
	}
	
	public static void cityName(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);
	}
	
	public static void zipCode(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);
	}
	
	public static void phonenumber(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_textbox(valuefrmlocclass, testdata);	
	}
	
	public static void countryName(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_dropdowns(valuefrmlocclass, testdata);
	}
	
	public static void stateName(String valuefrmlocclass, String testdata) {
		ActionKeywords.handling_dropdowns(valuefrmlocclass, testdata);
	}
}
