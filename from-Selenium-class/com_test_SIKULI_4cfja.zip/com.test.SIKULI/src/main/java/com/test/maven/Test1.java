package com.test.maven;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Test1 {
public static WebDriver driver;
	
	@BeforeMethod
	@Parameters({"brsName"})
	public static WebDriver selectBrowser(String brsName) {
			
		if (brsName.equalsIgnoreCase("chrome")) {
			  System.setProperty("webdriver.chrome.driver", "C:\\Automation\\chromedriver_win32\\chromedriver.exe");
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();
		} else if (brsName.equalsIgnoreCase("firefox")) {
			 System.setProperty("webdriver.gecko.driver", "C:\\Automation\\geckodriver-v0.20.1-win64\\geckodriver.exe");
     		   driver = new FirefoxDriver();
		} else {
			System.out.println("Browser name is wrong");
		}
		return driver;
	  }
  
  @Test
  @Parameters({"url","firstName"})
  public void f(String url, String firstName) throws Exception {
	  	
		driver.get(url);
		driver.findElement(By.name("firstname")).sendKeys(firstName);
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0,700)");
		
		Thread.sleep(5000);
		
		Pattern choosefilebtn = new Pattern("C:\\26MayWeekEnd\\com.test.SIKULI\\images\\choosefile.PNG");
		Pattern filenametextbox = new Pattern("C:\\26MayWeekEnd\\com.test.SIKULI\\images\\filename.PNG");
		Pattern openbtn = new Pattern("C:\\26MayWeekEnd\\com.test.SIKULI\\images\\openbtn.PNG");
		
		Thread.sleep(5000);
		
		Screen s = new Screen();
		
		s.click(choosefilebtn);
		Thread.sleep(5000);
		
		s.type(filenametextbox, "C:\\26MayWeekEnd\\com.test.SIKULI\\Screen Shot 02-16-18 at 02.31 PM.PNG");
		
		s.click(openbtn);
		
		Thread.sleep(5000);
		driver.findElement(By.id("profession-1")).click();
		
  }
}
