package utilities;

public class Locator_Values {
	
		public static String mmbrshplnk = "xpath://*[@id=\"ctl00_topMegaMenu_deskTopMenu\"]/div/ul/li[1]/a";
		public static String individualLink = "linkText:Individual";
		public static String totalpriceshpngcart = "xpath://*[@id=\"ctl00_body_lblSummary_Total\"]";
		public static String createaccnt = "linkText:Create an Account";
		public static String cartVal = "xpath://*[@id=\"totalPrice\"]";
		public static String joinNowbtn = "name:ctl00$Body$btnJoinNow";
		public static String frstName = "name:ctl00$Body$tbxNPFirstName";
		public static String lasttName = "name:ctl00$Body$tbxNPLastName";
		public static String userName = "name:ctl00$Body$rgUserName";
		public static String password = "name:ctl00$Body$rgPassword";
		public static String cnfrmpsswd = "name:ctl00$Body$ConfirmPassword";
		public static String emailid = "name:ctl00$Body$Email";
		public static String companyName = "name:ctl00$Body$tbxNPCompany";
		public static String streetName = "name:ctl00$Body$tbxNPStreet";
		public static String cityName = "name:ctl00$Body$tbxNPCity";
		public static String zipCode = "name:ctl00$Body$tbxNPZip";
		public static String phonenumber = "name:ctl00$Body$txtNPPhone";
		public static String countryName = "name:ctl00$Body$ddlNPCountry";
		public static String stateName = "name:ctl00$Body$ddlNPRegion";
}
